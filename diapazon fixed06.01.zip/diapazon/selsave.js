var select1 = document.getElementById('start_year');
var select2 = document.getElementById('start_month');
var select3 = document.getElementById('end_year');
var select4 = document.getElementById('end_month');

if (localStorage.getItem('selectedValue1')) {
  select1.value = localStorage.getItem('selectedValue1');
}

if (localStorage.getItem('selectedValue2')) {
  select2.value = localStorage.getItem('selectedValue2');
}
if (localStorage.getItem('selectedValue3')) {
  select3.value = localStorage.getItem('selectedValue3');
}

if (localStorage.getItem('selectedValue4')) {
  select4.value = localStorage.getItem('selectedValue4');
}

select1.addEventListener('change', function() {
  localStorage.setItem('selectedValue1', select1.value);
});

select2.addEventListener('change', function() {
  localStorage.setItem('selectedValue2', select2.value);
});
select3.addEventListener('change', function() {
  localStorage.setItem('selectedValue3', select3.value);
});

select4.addEventListener('change', function() {
  localStorage.setItem('selectedValue4', select4.value);
});