<?php 
class SiteClass {
	private $conn = ""; 	
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","mydata");
	}	

			
				 
				 
	public function start_date(){
		$years = range(1995, 2005);
	 
		 	$i=0;
			 foreach($years as $month => $value){
				$i=0;
			   echo "<option value={$value}>{$value}</option>";
			}
	 
	}
	public function end_date(){
		 
		$years = range(2005, 2012);
		$i=0;
		foreach($years as $month => $value){
		   $i=0;
		  echo "<option value={$value}>{$value}</option>";
	   }
	}

	public function start_mouth(){
		
		$months = [
			"январь" => 1,
			"февраль" => 2,
			"март" => 3,
			"апрель" => 4,
			"май" => 5,
			"июнь" => 6,
			"июль" => 7,
			"август" => 8,
			"сентябрь" => 9,
			"октябрь" => 10,
			"ноябрь" => 11,
			"декабрь" => 12,
		];
		 	$i=0;
			 foreach($months as $month => $value){
				$i=0;
			   echo "<option value={$value}>{$month}</option>";
			}
	 
	}
	public function end_mouth(){
		
		$months = [
			"январь" => 1,
			"февраль" => 2,
			"март" => 3,
			"апрель" => 4,
			"май" => 5,
			"июнь" => 6,
			"июль" => 7,
			"август" => 8,
			"сентябрь" => 9,
			"октябрь" => 10,
			"ноябрь" => 11,
			"декабрь" => 12,
		];
		 	 
			 foreach($months as $month => $value){
				 
			   echo "<option value={$value}>{$month}</option>";
			}
	 
	}
	function countFullWeeks($n) {
		$totalWeeks = floor($n / 7); // Количество целых недель в промежутке
		
		return $totalWeeks;
	  }
		public function result(){
			print_r($_POST);
			$startdate=(int)$_POST['start_date'];
			$end_date=(int)$_POST['end_date'];
			$promesh=$end_date-$startdate;
			$startYear = $startdate; // Год начала промежутка
			$endYear = $end_date; // Год конца промежутка
			$days = ($endYear - $startYear + 1) * 365; // Общее количество дней в промежутке с учетом високосных годов

			$totalWeeksCount = $this->countFullWeeks($days);
			$start_mouth=(int)$_POST['start_mouth'];	 
			$end_mouth=(int)$_POST['end_mouth'];
			$mouth_count=$end_mouth-$start_mouth;
			 
			echo "<h2>Месяцев в выбранном промежутке: ".$mouth_count ."</h2>";
			echo "<h2> Промежуток: ".$promesh ."</h2>";
			echo "<h2>количество недель: ".$totalWeeksCount."</h2>";
		}	
		 
		  
}

 ?>