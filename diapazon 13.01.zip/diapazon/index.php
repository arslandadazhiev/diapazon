<?php
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            
            if (!isset($_GET['start_year'])) {
                $_GET['start_year'] = 1995;
            }
            if (!isset($_GET['start_month'])) {
                $_GET['start_month'] = "";
            }
            if (!isset($_GET['end_year'])) {
                $_GET['end_year'] = 2005;
            }
            if (!isset($_GET['end_month'])) {
                $_GET['end_month'] = "";
            }
            $startYear = $_GET['start_year'];
            $startMonth = $_GET['start_month'];
            $endYear = $_GET['end_year'];
            $endMonth = $_GET['end_month'];
        
            
            $startTimestamp = strtotime($startYear . '-' . $startMonth . '-01');
            $endTimestamp = strtotime($endYear . '-' . $endMonth . '-01');

            $totalMonths = (date('Y', $endTimestamp) - date('Y', $startTimestamp)) * 12
                + (date('m', $endTimestamp) - date('m', $startTimestamp)) + 1;

            $totalWeeks = floor(($endTimestamp - $startTimestamp) / (7 * 24 * 60 * 60));
            echo  "<div class=\" w-50 m-auto\">";
            echo "<h3> Месяцев в выбранном промежутке:  " . $totalMonths . " </h3><br>";
            echo "<h3>Целых недель по 7 дней попадает в выбранный промежуток:   " . $totalWeeks."</h3>";
            echo "</div>";
        }
 
?>
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="assets/js/color-modes.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.115.4">
    <title>Задание с диапазоном</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="jqui/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-3.7.1.js"></script>
<script src="jqui/jquery-ui.js"></script>
<link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
 
<main class=" w-50 m-auto">
  <form method="" action="">
        <label for="start_year">Начальный год:</label>
        <select name="start_year" id="start_year"  class="form-select"  aria-label="Default select example">
            <?php 
            for($i=1995;$i<2005;$i++){
                if(!empty($_GET['start_year']) && $_GET['start_year']==$i){
                    echo "<option selected value=\"$i\">$i</option>";
                }else{
                    echo "<option value=\"$i\">$i</option>";
                } 
            }
            ?>
        </select>
        <br>
        
        <label for="start_month">Начальный месяц:</label>
        <select name="start_month" id="start_month"  class="form-select"  aria-label="Default select example">
        <?php for ($month = 1; $month <= 12; $month++) {
                $selected = ($month == $_GET['start_month']) ? ' selected' : '';  
                ?>
                <option value="<?php echo $month; ?>"<?php echo $selected; ?>><?php echo date('F', strtotime("2000-$month-01")); ?></option>
            <?php }?>
        </select>
        <br>
        
        <label for="end_year">Завершающий год:</label>
        <select name="end_year" id="end_year"   class="form-select" aria-label="Default select example">
        <?php 
            for($i=2005;$i<2012;$i++){
                if(!empty($_GET['end_year']) && $_GET['end_year']==$i){
                    echo "<option selected value=\"$i\">$i</option>";
                }else{
                    echo "<option value=\"$i\">$i</option>";
                } 
            }
            ?>
        </select>
        <br>
        
        <label for="end_month">Завершающий месяц:</label>
        <select name="end_month" id="end_month"  class="form-select"  aria-label="Default select example">
            <?php for ($month = 1; $month <= 12; $month++) {
                $selected = ($month == $_GET['end_month']) ? ' selected' : '';  
                ?>
                <option value="<?php echo $month; ?>"<?php echo $selected; ?>><?php echo date('F', strtotime("2000-$month-01")); ?></option>
            <?php }?>
        </select>
        <br>
        
        <input type="submit" class="btn btn-light" value="Отправить">
    </form>
</main> 
<script src="selsave.js"></script>
    </body>
</html>
